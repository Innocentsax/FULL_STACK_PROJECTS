package com.decagon.adire.dto.request;

import lombok.Data;

@Data
public class Oauth2DTO {
    private String firstName;
    private String surName;
    private String email;
}
