package com.decagon.adire.controller;
import com.decagon.adire.dto.request.IncomeReportRequestDto;
import com.decagon.adire.dto.request.OrderDTO;
import com.decagon.adire.dto.response.AppResponse;
import com.decagon.adire.dto.response.IncomeReportResponse;
import com.decagon.adire.service.OrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.Valid;
import java.net.URI;


@RestController
@RequiredArgsConstructor
@Slf4j
@RequestMapping("/api/order")
public class OrderController {
    private final OrderService orderService;

//    @PostMapping(path = "/create")
//    public ResponseEntity<AppResponse<?>> createOrder(@RequestBody @Valid final OrderDTO orderDTO) {
//        log.info("controller register: register user :: [{}] ::",orderDTO.getDesignerId());
//        IncomeReportResponse response = orderService.getIncomeReportByDate(orderDTO);
//        URI uri = URI.create(ServletUriComponentsBuilder.fromCurrentContextPath().path("/api/order/create").toUriString());
//        return ResponseEntity.created(uri).body(AppResponse.builder()
//                .result(response)
//                .message("Successfully Created")
//                .status(HttpStatus.CREATED).build());}
                @PostMapping(path = "/report")
    public ResponseEntity<?>  getAllOrderIncomeReport(@RequestBody @Valid final IncomeReportRequestDto incomeReportRequestDto) {
        return new ResponseEntity<>(orderService.getIncomeReportByDate(incomeReportRequestDto), HttpStatus.OK);
    }
}

