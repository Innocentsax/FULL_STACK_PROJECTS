package com.decagon.adire.controller;

import com.decagon.adire.dto.request.CustomerDTO;
import com.decagon.adire.dto.response.AppResponse;
import com.decagon.adire.dto.response.CustomerResponseDTO;
import com.decagon.adire.service.DesignerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.Valid;
import java.net.URI;

@RestController
@RequestMapping("/adire/designer")
public class DesignerController {
    @Autowired
    private DesignerService designerService;


    @GetMapping (path = "/demo")
    public String registerCustomer() {
        return "Hello";
    }

}
