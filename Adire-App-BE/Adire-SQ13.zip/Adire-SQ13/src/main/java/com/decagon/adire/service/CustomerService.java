package com.decagon.adire.service;

import com.decagon.adire.dto.request.CustomerDTO;
import com.decagon.adire.dto.response.CustomerResponseDTO;
import com.decagon.adire.entity.Customer;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface CustomerService {
    CustomerResponseDTO createCustomer(CustomerDTO requestDTO);
    List<Customer> getAllCustomers();
    Customer editCustomerById(String Id, CustomerDTO customerDto);

    Customer getCustomerById(String Id) throws RuntimeException;

    void deleteCustomer(String Id);
}
