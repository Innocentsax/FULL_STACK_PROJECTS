package com.decagon.adire.service.implementation;

import com.decagon.adire.dto.request.IncomeReportRequestDto;
import com.decagon.adire.dto.response.IncomeReportResponse;
import com.decagon.adire.entity.Designer;
import com.decagon.adire.entity.Order;
import com.decagon.adire.exception.CustomException;
import com.decagon.adire.exception.UserNotFoundException;
import com.decagon.adire.repository.DesignerRepository;
import com.decagon.adire.repository.OrderRepository;
import com.decagon.adire.service.OrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {
    private final OrderRepository orderRepository;
    private final DesignerRepository designerRepository;

    @Override
    public IncomeReportResponse getIncomeReportByDate(IncomeReportRequestDto incomeReportRequestDto) {
        Designer designer = designerRepository.findById(incomeReportRequestDto.getDesignerId()).orElseThrow(() -> new UserNotFoundException("Designer not found"));

        if (incomeReportRequestDto.getEnd().isBefore(incomeReportRequestDto.getStart())){
            throw  new CustomException("Timeframe is invalid");
        }

        var start = Timestamp.valueOf(incomeReportRequestDto.getStart());
        var end = Timestamp.valueOf(incomeReportRequestDto.getEnd());
        //get the orders within timeframe
        List<Order> orderList = orderRepository.findAllByCreatedDateBetweenAndDesigner(start,end, designer);

        if (orderList.size() ==  0) {
            throw new CustomException("No Order Found");
        }
        Double amountOfSales = 0.0;

        for (Order order : orderList) {
            amountOfSales += order.getOrderQuotationCost();
        }

        return IncomeReportResponse.builder()
                .startDate(incomeReportRequestDto.getStart())
                .endDate(incomeReportRequestDto.getEnd())
                .numberOfOrders(orderList.size())
                .totalAmountOfSales(amountOfSales)
                .build();
    }
}

