package com.decagon.adire.service;

import org.springframework.stereotype.Service;

public interface OrderSummaryService {
}
