package com.decagon.adire.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class CustomerResponseDTO {
    private String firstName;
    private String lastname;
    private String email;
    private String phoneNumber;
    private String address;
}
