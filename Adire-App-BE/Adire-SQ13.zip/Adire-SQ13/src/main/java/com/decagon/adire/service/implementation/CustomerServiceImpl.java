package com.decagon.adire.service.implementation;

import com.decagon.adire.dto.request.CustomerDTO;
import com.decagon.adire.dto.response.CustomerResponseDTO;
import com.decagon.adire.entity.Customer;
import com.decagon.adire.exception.UserNotFoundException;
import com.decagon.adire.repository.CustomerRepository;
import com.decagon.adire.service.CustomerService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerService {
    @Autowired
    private final CustomerRepository customerRepository;
    @Autowired
    private final PasswordEncoder passwordEncoder;

    @Override
    public CustomerResponseDTO createCustomer(CustomerDTO requestDTO) {
        log.info("Check if user already exist");
        Customer existing= customerRepository.findCustomerByEmail(requestDTO.getEmail());
        if (existing!=null){
            throw new UserNotFoundException("Email already exist");
        }
        log.info("service:: about setting");
        Customer newCustomer= new Customer();
        newCustomer.setFirstName(requestDTO.getFirstName());
        newCustomer.setLastname(requestDTO.getLastName());
        newCustomer.setEmail(requestDTO.getEmail());
        newCustomer.setAddress(requestDTO.getAddress());
        newCustomer.setPhoneNumber(requestDTO.getPhoneNumber());
        Customer savedCustomer= customerRepository.save(newCustomer);

        log.info("Service:: Creating Customer Response DTO");
        CustomerResponseDTO responseDTO= new CustomerResponseDTO();
        responseDTO.setFirstName(savedCustomer.getFirstName());
        responseDTO.setLastname(savedCustomer.getLastname());
        responseDTO.setEmail(savedCustomer.getEmail());
        responseDTO.setAddress(savedCustomer.getAddress());
        responseDTO.setPhoneNumber(savedCustomer.getPhoneNumber());
        return responseDTO;
    }

    @Override
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    @Override
    public Customer editCustomerById(String Id, CustomerDTO customerDto) {
            Customer customer = getCustomerById(Id);
            customer.setFirstName(customerDto.getFirstName());
            customer.setLastname(customerDto.getLastName());
            customer.setEmail(customerDto.getEmail());
            customer.setPhoneNumber(customerDto.getPhoneNumber());
            customer.setPhoneNumber(customerDto.getPhoneNumber());
            return customerRepository.save(customer);
    }

    @Override
    public Customer getCustomerById(String Id) throws RuntimeException {
        return customerRepository.findById(Id)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
    }



    @Override
    public void deleteCustomer(String Id) {
        customerRepository.deleteById(Id);

    }
}
