package com.decagon.adire.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.time.LocalDateTime;


@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class IncomeReportResponse {

    private Double totalAmountOfSales;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private Integer numberOfOrders;

}
