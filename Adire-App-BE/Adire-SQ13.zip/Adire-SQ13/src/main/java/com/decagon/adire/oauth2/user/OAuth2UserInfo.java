package com.decagon.adire.oauth2.user;

import java.util.Map;

public abstract class OAuth2UserInfo {
    protected Map<String, Object> attributes;

    protected OAuth2UserInfo(Map<String, Object> attributes) {
        this.attributes = attributes;
    }

    public Map<String, Object> getAttributes() {
        return attributes;
    }

    public abstract String getId();

    public abstract String getUserName();

    public abstract String getEmail();

    public abstract String getImageUrl();

    public abstract String getPhoneNumber();

    public abstract String getFamilyName();

    public abstract String getGivenName();
}
