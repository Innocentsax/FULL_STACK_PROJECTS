package com.decagon.adire.entity;

import com.decagon.adire.enums.Provider;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "designers")
public class Designer extends BaseEntity {
    private String firstName;
    private  String lastName;
    private String email;
    private  String phoneNumber;
    private  String password;
    private  String confirmPassword;
    private String role;
    @Enumerated(EnumType.STRING)
    private Provider provider;
    private String providerId;
    @OneToMany(mappedBy = "designer", cascade = CascadeType.ALL)
    private List<Customer> customers;
    @OneToMany(mappedBy = "designer", cascade = CascadeType.ALL)
    private List<Order> orders;
}
