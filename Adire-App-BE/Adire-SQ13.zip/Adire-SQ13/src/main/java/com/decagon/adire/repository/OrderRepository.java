package com.decagon.adire.repository;

import com.decagon.adire.dto.response.IncomeReportResponse;
import com.decagon.adire.entity.Designer;
import com.decagon.adire.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;


public interface OrderRepository extends JpaRepository<Order, String> {


    List<Order> findAllByCreatedDateBetweenAndDesigner(Timestamp startDate, Timestamp endDate, Designer designer);

}
