package com.decagon.adire.controller;

import com.decagon.adire.dto.request.DesignerDTO;
import com.decagon.adire.dto.request.LoginDTO;
import com.decagon.adire.dto.response.AppResponse;
import com.decagon.adire.dto.response.UserResponseDto;
import com.decagon.adire.exception.CustomException;
import com.decagon.adire.security.jwt.TokenProvider;
import com.decagon.adire.service.DesignerService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.Valid;
import java.net.URI;

import static com.decagon.adire.security.jwt.TokenProvider.doesBothStringMatch;
import static com.decagon.adire.utils.SecurityConstants.PASSWORD_NOT_MATCH_MSG;



@Slf4j
//@Tag(name = "Authentication Controller")
@RestController
@AllArgsConstructor
@RequestMapping("/api/auth")
public class AuthController {

    private final DesignerService userService;

    private final AuthenticationManager authenticationManager;


    @PostMapping(path = "/register")
    public ResponseEntity<AppResponse<?>> registerUser(@RequestBody @Valid final DesignerDTO designerDTO) {
        log.info("controller register: register user :: [{}] ::", designerDTO.getEmail());
        validateDesginer(designerDTO);
        UserResponseDto response = userService.createUser(designerDTO);
        URI uri = URI.create(ServletUriComponentsBuilder.fromCurrentContextPath().path("/adire/auth/register").toUriString());
        return ResponseEntity.created(uri).body(AppResponse.builder()
                .result(response)
                .message("Successfully Registered")
                .status(HttpStatus.CREATED).build());
    }

    private void validateDesginer(DesignerDTO request) {
        log.info("validating user registration request for email :: {}", request.getEmail());
        if (!doesBothStringMatch(request.getConfirmPassword(), request.getPassword())) {
            throw new CustomException(PASSWORD_NOT_MATCH_MSG, HttpStatus.BAD_REQUEST);
        }
        log.info("successful validation for user registration request for email :: {}", request.getEmail());
    }


    @PostMapping("/login")
    public ResponseEntity<?> authenticateAndGetToken(@RequestBody LoginDTO request) {
        Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));

        if (authentication.isAuthenticated()) {
            String response = String.valueOf(TokenProvider.generate(authentication));
            return ResponseEntity.status(200)
                    .body(AppResponse
                            .builder()
                            .result(response)
                            .message("Authenticated")
                            .status(HttpStatus.OK)
                            .build());
        } else {
            throw new UsernameNotFoundException("invalid user request !");
        }
    }








}
