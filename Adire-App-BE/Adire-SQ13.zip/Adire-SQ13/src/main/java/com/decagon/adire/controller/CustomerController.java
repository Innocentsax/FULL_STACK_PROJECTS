package com.decagon.adire.controller;

import com.decagon.adire.dto.request.CustomerDTO;
import com.decagon.adire.dto.request.DesignerDTO;
import com.decagon.adire.dto.response.AppResponse;
import com.decagon.adire.dto.response.CustomerResponseDTO;
import com.decagon.adire.service.CustomerService;
//import io.swagger.v3.oas.annotations.Operation;
//import io.swagger.v3.oas.annotations.media.Content;
//import io.swagger.v3.oas.annotations.media.Schema;
//import io.swagger.v3.oas.annotations.responses.ApiResponse;
//import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.Valid;
import java.net.URI;

@Slf4j
@RestController
@RequestMapping("/api/customer")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @PostMapping(path = "/register")
//    @Operation(summary = "Register New Customer", responses = {
//            @ApiResponse(responseCode = "201",
//                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
//                            schema = @Schema(implementation = DesignerDTO.class)))})
    public ResponseEntity<AppResponse<?>> registerCustomer(@RequestBody @Valid final CustomerDTO customerDTO) {
        log.info("controller register: register user :: [{}] ::", customerDTO.getEmail());
        CustomerResponseDTO response = customerService.createCustomer(customerDTO);
        URI uri = URI.create(ServletUriComponentsBuilder.fromCurrentContextPath().path("/api/adire/customer/register").toUriString());
        return ResponseEntity.created(uri).body(AppResponse.buildSuccess(response));
    }

    @GetMapping
    public ResponseEntity<?>  getAllCustomers() {
        return new ResponseEntity<>(customerService.getAllCustomers(), HttpStatus.OK);
    }


    @PutMapping("/{Id}")
    public ResponseEntity<?> editCustomerById(@PathVariable("Id") String Id, @RequestBody CustomerDTO customerDto){
        return new ResponseEntity<>(customerService.editCustomerById(Id, customerDto), HttpStatus.OK);
    }

    @DeleteMapping("/{Id}")
    public ResponseEntity<?> deleteCustomer(@PathVariable String Id){
        customerService.deleteCustomer(Id);
        return new ResponseEntity<>("Customer deleted", HttpStatus.OK);
    }
}


