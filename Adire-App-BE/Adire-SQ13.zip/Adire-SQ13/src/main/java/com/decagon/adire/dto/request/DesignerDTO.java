package com.decagon.adire.dto.request;


import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

@Getter
@Setter
public class DesignerDTO {
    @NotBlank
    private String firstName;
    @NotBlank
    private  String lastName;
    @Email
    private String email;
    @NotBlank
    private  String phoneNumber;
    @NotBlank
    private  String password;
    @NotBlank
    private  String confirmPassword;

}
