package com.decagon.adire.mail;

import com.decagon.adire.entity.Designer;

public interface EmailService {

    void sendForgotPassword(Designer user, String url) throws Exception;

}
