package com.decagon.adire;

import com.decagon.adire.entity.Customer;
import com.decagon.adire.entity.Designer;
import com.decagon.adire.entity.Order;
import com.decagon.adire.repository.CustomerRepository;
import com.decagon.adire.repository.DesignerRepository;
import com.decagon.adire.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.time.LocalDateTime;

@SpringBootApplication
@RequiredArgsConstructor
public class AdireApplication {


    public static void main(String[] args) {
        SpringApplication.run(AdireApplication.class, args);

    }
//    @Override
//    public void run(String... args) throws Exception {
//
//        Designer designer = new Designer();
//
//        designer.setEmail("d@gmail.com");
//
//        designerRepository.save(designer);
//
//        Designer savedDesigner = designerRepository.findByEmail("d@gmail.com").get();
//
//        Order order1 = new Order();
//        order1.setProductMeasurement(12);
//        order1.setPhoneNumber("08107782786");
//        order1.setEmail("idowu@gmail.com");
//        order1.setProductQuantity(6);
//        order1.setOrderQuotationCost(2000.0);
//        order1.setPaymentDate(LocalDateTime.now());
//        order1.setIsCompleted(true);
//        order1.setDesigner(savedDesigner);
//        orderRepository.save(order1);
//
//        Order order2 = new Order();
//        order2.setProductMeasurement(12);
//        order2.setPhoneNumber("08107782786");
//        order2.setEmail("idowu@gmail.com");
//        order2.setProductQuantity(6);
//        order2.setOrderQuotationCost(2000.0);
//        order2.setPaymentDate(LocalDateTime.now());
//        order2.setIsCompleted(true);
//        order2.setDesigner(savedDesigner);
//        orderRepository.save(order2);
//
//        Order order3 = new Order();
//        order3.setProductMeasurement(12);
//        order3.setPhoneNumber("08107782786");
//        order3.setEmail("idowu@gmail.com");
//        order3.setProductQuantity(6);
//        order3.setOrderQuotationCost(2000.0);
//        order3.setPaymentDate(LocalDateTime.now());
//        order3.setIsCompleted(true);
//        order3.setDesigner(savedDesigner);
//        orderRepository.save(order3);
//
//        Order order4 = new Order();
//        order4.setProductMeasurement(12);
//        order4.setPhoneNumber("08107782786");
//        order4.setEmail("idowu@gmail.com");
//        order4.setProductQuantity(6);
//        order4.setOrderQuotationCost(2000.0);
//        order4.setPaymentDate(LocalDateTime.now());
//        order4.setIsCompleted(true);
//        order4.setDesigner(savedDesigner);
//        orderRepository.save(order4);
//
//        Order order5 = new Order();
//        order5.setProductMeasurement(12);
//        order5.setPhoneNumber("08107782786");
//        order5.setEmail("idowu@gmail.com");
//        order5.setProductQuantity(6);
//        order5.setOrderQuotationCost(2000.0);
//        order5.setPaymentDate(LocalDateTime.now());
//        order5.setIsCompleted(true);
//        order5.setDesigner(savedDesigner);
//        orderRepository.save(order5);
//    }


}
