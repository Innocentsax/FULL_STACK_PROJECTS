package com.decagon.adire.entity;

//import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "orders")
public class Order extends BaseEntity{


    private  Integer productMeasurement;
    private  String phoneNumber;
    private String email;
    private Integer productQuantity;
    private Double orderQuotationCost;
    private LocalDateTime paymentDate;
    private Boolean isCompleted =false;


    @ManyToOne
    @JoinColumn(name ="customerId", referencedColumnName = "id")
    private Customer customer;
    @OneToOne(mappedBy = "order")
    private Receipt receipt;
    @ManyToOne
    @JoinColumn(name = "designerId", referencedColumnName = "id")
    private Designer designer;

}
