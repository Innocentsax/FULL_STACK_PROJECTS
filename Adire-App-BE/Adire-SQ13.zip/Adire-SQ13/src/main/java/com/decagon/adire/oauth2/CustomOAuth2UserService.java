package com.decagon.adire.oauth2;
import com.decagon.adire.dto.response.UserResponseDto;
import com.decagon.adire.security.WebSecurityConfig;
import com.decagon.adire.entity.Designer;
import com.decagon.adire.enums.Provider;
import com.decagon.adire.oauth2.user.OAuth2UserInfo;
import com.decagon.adire.repository.DesignerRepository;
import com.decagon.adire.security.CustomUserDetails;
import com.decagon.adire.service.DesignerService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;

import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;


import java.util.Collections;

@Service
@RequiredArgsConstructor
public class CustomOAuth2UserService extends DefaultOAuth2UserService {

    private final DesignerRepository userRepository;
    private final DesignerService designerService;
    private final ObjectMapper objectMapper;

    @Override
    public OAuth2User loadUser(OAuth2UserRequest oAuth2UserRequest) throws OAuth2AuthenticationException {
        OAuth2User oAuth2User = super.loadUser(oAuth2UserRequest);

        try {
            return processOAuth2User(oAuth2UserRequest, oAuth2User);
        } catch (AuthenticationException ex) {
            throw ex;
        } catch (Exception ex) {
            // Throwing an instance of AuthenticationException will trigger the OAuth2AuthenticationFailureHandler
            throw new InternalAuthenticationServiceException(ex.getMessage(), ex.getCause());
        }
    }

    private CustomUserDetails processOAuth2User(OAuth2UserRequest userRequest, OAuth2User oAuth2User) {
        String providerName = userRequest.getClientRegistration().getRegistrationId();
        if (providerName.equalsIgnoreCase(Provider.GOOGLE.name()) || providerName.equalsIgnoreCase(Provider.FACEBOOK.name())) {
            OAuth2UserInfo auth2UserInfo = objectMapper.convertValue(oAuth2User.getAttributes(), OAuth2UserInfo.class);

            Designer userOptional = designerService.findByEmail(auth2UserInfo.getUserName());
            Designer user = null;
            if (userOptional == null) {
                user = new Designer();
                user.setFirstName(auth2UserInfo.getGivenName());
                user.setLastName(auth2UserInfo.getFamilyName());
                user.setEmail(auth2UserInfo.getEmail());
                user.setRole(WebSecurityConfig.USER);
                user.setProvider(Provider.valueOf(providerName));
                user.setProviderId(auth2UserInfo.getId());
                UserResponseDto responseDto = designerService.saveOAuth2User(user);
            } else {
                user.setEmail(auth2UserInfo.getEmail());
                user.setFirstName(auth2UserInfo.getGivenName());
            }
            CustomUserDetails customUserDetails = new CustomUserDetails();
            customUserDetails.setId(user.getId());
            customUserDetails.setUsername(auth2UserInfo.getUserName());
            customUserDetails.setName(auth2UserInfo.getGivenName());
            customUserDetails.getLastName(auth2UserInfo.getFamilyName());
            customUserDetails.setEmail(auth2UserInfo.getEmail());
            customUserDetails.setAttributes(oAuth2User.getAttributes());
            customUserDetails.setAuthorities(Collections.singletonList(new SimpleGrantedAuthority(user.getRole())));
            return customUserDetails;
        } else {
            throw new InternalAuthenticationServiceException(String.format("The OAuth2 provider %s is not supported yet", providerName));
        }
    }





}
