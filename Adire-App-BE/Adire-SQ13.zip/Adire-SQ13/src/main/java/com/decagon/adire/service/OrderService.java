package com.decagon.adire.service;

import com.decagon.adire.dto.request.IncomeReportRequestDto;
import com.decagon.adire.dto.response.IncomeReportResponse;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Map;

@Service
public interface OrderService {
    IncomeReportResponse getIncomeReportByDate(IncomeReportRequestDto incomeReportRequestDto);

}
