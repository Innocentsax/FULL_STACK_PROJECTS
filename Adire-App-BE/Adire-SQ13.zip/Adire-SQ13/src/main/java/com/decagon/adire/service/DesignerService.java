package com.decagon.adire.service;

import com.decagon.adire.dto.request.DesignerDTO;
import com.decagon.adire.dto.request.Oauth2DTO;
import com.decagon.adire.dto.response.UserResponseDto;
import com.decagon.adire.entity.Designer;


public interface DesignerService {

   Designer getLoggedInUser();
   Designer findByEmail(String email);

   UserResponseDto createUser(DesignerDTO designerDTO);

   UserResponseDto saveOAuth2User(Designer request);

}
