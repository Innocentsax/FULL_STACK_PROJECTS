package com.decagon.adire.mail;

import com.decagon.adire.entity.Designer;
import lombok.RequiredArgsConstructor;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.springframework.stereotype.Service;

import java.io.StringWriter;

@Service
@RequiredArgsConstructor
public class EmailServiceImpl implements EmailService{

    private final VelocityEngine velocityEngine;

    private final EmailClient emailClient;


    @Override
    public void sendForgotPassword(Designer designer, String url) throws Exception {
        Template template = velocityEngine.getTemplate("template/forgot_password.vm");
        VelocityContext context = new VelocityContext();
        context.put("name", designer.getFirstName());
        context.put("link", url);
        StringWriter stringWriter = new StringWriter();
        template.merge(context, stringWriter);

        emailClient.sendMail(designer.getEmail(), "Forgot Password", stringWriter.toString());
    }



}
