package com.decagon.adire.service.implementation;

import com.decagon.adire.repository.OrderRepository;
import com.decagon.adire.service.OrderSummaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderSummaryImpl implements OrderSummaryService {
    @Autowired
    private OrderRepository orderRepository;
}
