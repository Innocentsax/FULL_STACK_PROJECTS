package com.decagon.adire.service.implementation;

import com.decagon.adire.dto.request.DesignerDTO;
import com.decagon.adire.dto.request.Oauth2DTO;
import com.decagon.adire.dto.response.UserResponseDto;
import com.decagon.adire.entity.Designer;
import com.decagon.adire.entity.VerificationToken;
import com.decagon.adire.enums.Provider;
import com.decagon.adire.exception.CustomException;
import com.decagon.adire.repository.DesignerRepository;
import com.decagon.adire.repository.VerificationTokenRepository;
import com.decagon.adire.service.DesignerService;
import com.decagon.adire.utils.AppUtil;
import com.decagon.adire.utils.EmailValidatorService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Collections;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.locks.ReentrantLock;

@Slf4j
@Service
@RequiredArgsConstructor
public class DesignerServiceImpl implements DesignerService, UserDetailsService {

    private final DesignerRepository designerRepository;
    private final PasswordEncoder passwordEncoder;
    private final VerificationTokenRepository verificationTokenRepository;
    private final ReentrantLock lock = new ReentrantLock(true);



    private String generateVerificationToken(Designer user) {
        log.info("inside generateVerificationToken, generating token for {}", user.getEmail());
        String token = UUID.randomUUID().toString();
        VerificationToken verificationToken = new VerificationToken();
        verificationToken.setUser(user);
        verificationToken.setToken(token);
        log.info("Saving token to database");
        verificationTokenRepository.save(verificationToken);
        return token;
    }

    @Override
    public Designer getLoggedInUser() {
        String loggedInUser = AppUtil.getPrincipal();
        if (loggedInUser.equalsIgnoreCase("system"))
            throw new CustomException("user not found");
        log.info("AccountServiceImpl getLoggedInUserAccountDetails- logged In user :: [{}]", loggedInUser);
        return designerRepository.findByEmail(loggedInUser).orElseThrow(
                () -> {
                    throw new CustomException("user not found");
                }
        );
    }

    @Override
    public Designer findByEmail(String email) {
        return designerRepository.findByEmail(email).orElseThrow(
                () -> {
                    throw new CustomException("user not found");
                }
        );
    }

    @Override
    public UserResponseDto createUser(DesignerDTO request) {
        if ("".equals(request.getEmail().trim())) {
            throw new CustomException("Email can not be empty");
        }
        String email = request.getEmail().toLowerCase();
        if(!EmailValidatorService.isValid(email)){
            throw new CustomException("Enter a valid email address");
        }
        var newUser = designerRepository.findByEmail(email);
        if (newUser.isPresent()) {
            throw new CustomException("User already exist");
        }
        Designer user = new Designer();
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setEmail(request.getEmail());
        user.setPhoneNumber(request.getPhoneNumber());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setConfirmPassword(passwordEncoder.encode(request.getConfirmPassword()));
        user.setRole("ROLE_DESIGNER");
        log.info("about saving");
        Designer saveUser = designerRepository.save(user);
        return new UserResponseDto(saveUser.getEmail(), saveUser.getRole());
    }

    @Override
    public UserResponseDto saveOAuth2User(Designer request) {
            Designer saveUser = designerRepository.save(request);
            log.info("saved oauth2 user");
            return new UserResponseDto(saveUser.getEmail(), saveUser.getRole());
    }


    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        log.info("userService loadUserByUserName - email :: [{}] ::", email);
        Designer designer = designerRepository.findByEmail(email)
                .orElseThrow(
                        () -> {
                            throw new CustomException("User not found");
                        }
                );
        Collection<SimpleGrantedAuthority> authorities =
                Collections.singleton(new SimpleGrantedAuthority(designer.getRole()));
        return new org.springframework.security.core.userdetails.User(designer.getEmail(), designer.getPassword(), authorities);
    }








}


