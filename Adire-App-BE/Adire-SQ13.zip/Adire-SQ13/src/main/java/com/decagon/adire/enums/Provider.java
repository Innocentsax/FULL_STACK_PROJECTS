package com.decagon.adire.enums;

public enum Provider {
    LOCAL,
    GOOGLE,
    FACEBOOK

}
