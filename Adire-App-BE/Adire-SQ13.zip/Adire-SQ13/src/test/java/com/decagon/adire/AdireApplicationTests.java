package com.decagon.adire;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class AdireApplicationTests {

    @Test
    void contextLoads() {
    }

}
